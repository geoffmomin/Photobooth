We worked in a group of 3. The names and SID's are in Authors.txt.


How to run our app:

Go to /home/nexisn4 on our server and run "node tripleThreatServer.js" and server will start.
Our server file (tripleThreatServer.js) and database file (photos.db) is on /home/nexisn4 on the server we're using (138.68.25.50). our port is 8650.
On the server, we have public folder, where photos are stored. 
Our main.html/css/js on public/run and icons,assets are in public/run/photobooth.


Go to a browser and type "http://138.68.25.50:8650/run/main.html" in the url. our app will load.